<?php require 'config.php';
$rows=$pdo->query("SELECT t.id_transaksi,t.tanggal_transaksi,u.nama,t.status_pesanan,t.total_harga FROM transaksi t JOIN users u ON u.id_user=t.id_user ORDER BY t.tanggal_transaksi DESC")->fetchAll();
$total=$pdo->query("SELECT COALESCE(SUM(total_harga),0) FROM transaksi")->fetchColumn();require 'header.php';?>
<h2 class="page-title">Laporan Transaksi</h2><p class="text-muted mb-4">Ringkasan seluruh transaksi Dapur Digital.</p>
<div class="cardx mb-4"><small class="text-muted">Total Omzet</small><div class="display-6 fw-bold text-primary">Rp <?=number_format($total,0,',','.')?></div></div>
<div class="cardx table-responsive"><table class="table"><thead><tr><th>ID</th><th>Tanggal</th><th>Pelanggan</th><th>Status</th><th>Total</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td>#<?=$r['id_transaksi']?></td><td><?=date('d/m/Y H:i',strtotime($r['tanggal_transaksi']))?></td><td><?=htmlspecialchars($r['nama'])?></td><td><span class="badge-soft"><?=htmlspecialchars($r['status_pesanan'])?></span></td><td>Rp <?=number_format($r['total_harga'],0,',','.')?></td></tr><?php endforeach;?></tbody></table></div>
<?php require 'footer.php'; ?>