DAPUR DIGITAL - WARUNG BU MITA
================================

CARA INSTALL DI XAMPP:
1. Copy folder "dapur_digital" ke:
   C:\xampp\htdocs\

2. Jalankan Apache dan MySQL dari XAMPP.

3. Buka phpMyAdmin:
   http://localhost/phpmyadmin

4. Import file:
   database.sql

5. Buka website:
   http://localhost/dapur_digital/

AKUN CONTOH:
Admin:
email    : admin@dapur.test
password : admin123

Pelanggan:
email    : budi@dapur.test
password : 123456

CATATAN:
- Website ini dibuat PHP Native + MySQL + Bootstrap.
- Data password contoh masih plaintext karena ini versi jobsheet/demo.
- Untuk aplikasi produksi, password sebaiknya memakai password_hash().
- Struktur database sesuai jobsheet: users, menu, bahan_baku, transaksi, detail_transaksi.
- Relasi:
  users 1:N transaksi
  transaksi 1:N detail_transaksi
  menu 1:N detail_transaksi
