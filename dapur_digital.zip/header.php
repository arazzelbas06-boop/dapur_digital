<?php
$page = basename($_SERVER['PHP_SELF']);
?>
<!doctype html><html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dapur Digital - Warung Bu Mita</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head><body>
<aside class="sidebar">
<div class="brand">🍳 Dapur Digital<small>Warung Bu Mita</small></div>
<a href="index.php" class="<?= $page=='index.php'?'active':'' ?>">🏠 Dashboard</a>
<a href="menu.php" class="<?= $page=='menu.php'?'active':'' ?>">🍽️ Menu</a>
<a href="bahan.php" class="<?= $page=='bahan.php'?'active':'' ?>">📦 Bahan Baku</a>
<a href="users.php" class="<?= $page=='users.php'?'active':'' ?>">👥 Pengguna</a>
<a href="transaksi.php" class="<?= $page=='transaksi.php'?'active':'' ?>">🧾 Transaksi</a>
<a href="laporan.php" class="<?= $page=='laporan.php'?'active':'' ?>">📊 Laporan</a>
</aside><main class="main">
<div class="topbar d-flex justify-content-between align-items-center">
<div><div class="fw-bold">Sistem Informasi Dapur Digital</div><small class="text-muted">Kelola menu, stok, pelanggan, dan transaksi</small></div>
<div class="badge-soft">Admin</div>
</div>