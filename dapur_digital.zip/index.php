<?php require 'config.php';
$menu=$pdo->query("SELECT COUNT(*) FROM menu")->fetchColumn();
$bahan=$pdo->query("SELECT COUNT(*) FROM bahan_baku")->fetchColumn();
$users=$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$transaksi=$pdo->query("SELECT COUNT(*) FROM transaksi")->fetchColumn();
$omzet=$pdo->query("SELECT COALESCE(SUM(total_harga),0) FROM transaksi")->fetchColumn();
$stok=$pdo->query("SELECT COUNT(*) FROM bahan_baku WHERE jumlah_stok<=stok_minimum")->fetchColumn();
require 'header.php'; ?>
<div class="mb-4"><div class="d-flex align-items-center gap-2 mb-1"><span class="badge-soft">IKHTISAR OPERASIONAL</span></div><h2 class="page-title mb-1">Dapur hari ini</h2><p class="text-muted mb-0">Selamat datang di Dapur Digital Warung Bu Mita.</p></div>
<div class="row g-4 mb-4">
<?php foreach([['🍽️','Total Menu',$menu],['📦','Bahan Baku',$bahan],['👥','Pengguna',$users],['🧾','Transaksi',$transaksi]] as $s): ?>
<div class="col-md-3"><div class="cardx stat"><div><small class="text-muted"><?=$s[1]?></small><h3 class="fw-bold mt-2 mb-0"><?=$s[2]?></h3></div><div class="icon"><?=$s[0]?></div></div></div>
<?php endforeach; ?>
</div>
<div class="row g-4"><div class="col-md-8"><div class="cardx"><h5 class="fw-bold">Ringkasan Keuangan</h5><div class="display-6 fw-bold text-primary mt-3">Rp <?=number_format($omzet,0,',','.')?></div><p class="text-muted">Total nilai transaksi tersimpan.</p></div></div>
<div class="col-md-4"><div class="cardx"><h5 class="fw-bold">⚠️ Stok Menipis</h5><div class="display-6 fw-bold text-danger mt-3"><?=$stok?></div><p class="text-muted">Bahan berada di bawah batas minimum.</p></div></div></div>
<?php require 'footer.php'; ?>